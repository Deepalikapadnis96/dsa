package com.ntt.task.thread;

public class DemoThread {
public static void main(String[] args) {
	System.out.println(Thread.currentThread().getName());
}
}

package com.ntt.task.thread;

public class RunnableImpl implements Runnable {

	@Override
	public void run() {
		for (int i = 0; i < 5; i++) {
			System.out.println("in runnable child");
		}
	}

}

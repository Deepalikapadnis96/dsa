package com.ntt.task;

import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;

public class StringToTimestamp {
public static void main(String[] args) {
	String str ="22-12-2020";

	DateTimeFormatter isoDate = DateTimeFormatter.ofPattern("dd-MM-yyyy");
	LocalDate parse = LocalDate.parse(str, isoDate);
	DateTimeFormatter isoDate1 = DateTimeFormatter.ofPattern("yyyy-MM-dd");
	String format = parse.format(isoDate1);
	System.out.println(format);
	
	LocalDateTime atStartOfDay = parse.atStartOfDay();
	Instant instant = atStartOfDay.toInstant(ZoneOffset.UTC);
	System.out.println(instant);
}
}

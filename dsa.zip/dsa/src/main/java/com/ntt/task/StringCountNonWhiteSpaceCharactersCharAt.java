package com.ntt.task;

public class StringCountNonWhiteSpaceCharactersCharAt {

	public static void main(String[] args) {

		String str = "This is a sample string";
		int count = 0;
		// count each characters except spaces
		for (int i = 0; i < str.length(); i++) {
			if (str.charAt(i) != ' ') {
				count++;
			}
		}
		System.out.println("Length of the String: " + count);
	}

}

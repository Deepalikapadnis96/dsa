package com.ntt.task;

public class Que4EvenAndOdd {
	public static void main(String[] args) {

		int[] array = { 3, 44, 56, 76, 8, 9, 23, 4 };
		for (int i = 0; i < array.length; i++) {
			if ((array[i ]% 2) == 0) {
				System.out.println("is a even num " +array[i]);
			} else {
				System.out.println("odd num:" +i);
			}
		}
		for (int i = 0; i < array.length; i++) {
			if ((i % 2) != 0) {
				System.out.println("odd :" + i);

			}
		}
	}
}
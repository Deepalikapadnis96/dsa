package com.ntt.task;

public class StringStartWith {
	public static void main(String[] args) {
		// The Java String class startsWith() method checks if this string starts with
		// the given prefix
		String s1 = "there is no data in the string";
		System.out.println(s1.startsWith("th"));
		System.out.println(s1.startsWith("there is"));
		System.out.println(s1.startsWith("e", 2));// bcz "e" is on 2nd position
		System.out.println(s1.startsWith("There"));// "T" is capital i.e=false

	}
}

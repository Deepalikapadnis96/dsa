package com.ntt.task.stack;

public class DynamicStack {
	private int maxSize; // Maximum size of the stack
	private int[] stackArray; // Array to store stack elements
	private int top; // Index of the top element

	// Constructor to initialize the stack
	public DynamicStack(int initialSize) {
		maxSize = initialSize;
		stackArray = new int[maxSize];
		top = -1; // Stack is initially empty
	}

	// Resize the stack array
	private void resize(int newSize) {
		int[] temp = new int[newSize];
		System.arraycopy(stackArray, 0, temp, 0, top + 1);
		stackArray = temp;
		maxSize = newSize;
	}

	// Check if the stack is full
	private boolean isFull() {
		return (top == maxSize - 1);
	}

	// Push an element to the top of the stack
	public void push(int x) {
		if (isFull()) {
			resize(maxSize * 2); // Double the size of the array
		}
		stackArray[++top] = x; // Increment top and insert element
	}

	// Check if the stack is empty
	public boolean isEmpty() {
		return (top == -1);
	}

	// Pop the top element from the stack
	public int pop() {
		if (isEmpty()) {
			throw new RuntimeException("Stack is empty. Cannot pop element.");
		}
		int element = stackArray[top--]; // Return element and decrement top
		if (top > 0 && top == maxSize / 4) {
			resize(maxSize / 2); // Halve the size of the array
		}
		return element;
	}

	// Peek the top element without removing it
	public int peek() {
		if (isEmpty()) {
			throw new RuntimeException("Stack is empty. Cannot peek element.");
		}
		return stackArray[top];
	}

	// Display the elements of the stack
	public void display() {
		if (isEmpty()) {
			System.out.println("Stack is empty.");
		} else {
			System.out.print("Stack elements: ");
			for (int i = 0; i <= top; i++) {
				System.out.print(stackArray[i] + " ");
			}
			System.out.println();
		}
	}
}

class DynamicStackImplementation {
	public static void main(String[] args) {
		DynamicStack stack = new DynamicStack(2); // Create a stack with an initial size of 2

		// Push elements to the stack
		stack.push(10);
		stack.push(20);
		stack.push(30);
		stack.push(40);

		// Display the stack
		stack.display(); // Output: Stack elements: 10 20 30 40

		// Peek the top element
		System.out.println("Top element: " + stack.peek()); // Output: Top element: 40

		// Pop elements from the stack
		System.out.println("Popped element: " + stack.pop()); // Output: Popped element: 40
		System.out.println("Popped element: " + stack.pop()); // Output: Popped element: 30

		// Display the stack
		stack.display(); // Output: Stack elements: 10 20

		// Push more elements to trigger resizing
		stack.push(50);
		stack.push(60);

		// Display the stack
		stack.display(); // Output: Stack elements: 10 20 50 60

		// Check if the stack is empty
		System.out.println("Is stack empty? " + stack.isEmpty()); // Output: Is stack empty? false
	}
}

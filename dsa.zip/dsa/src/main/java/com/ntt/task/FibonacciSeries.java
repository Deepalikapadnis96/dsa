package com.ntt.task;

import java.util.stream.Stream;

public class FibonacciSeries {
	public static void main(String[] args) {
		int n = 11;
		int f = 0;
		int l = 1;
		for (int i = 0; i < n; i++) {
			int next = f + l;
			f = l;
			l = next;
			System.out.println("first>" + next);

		}
		System.out.println("---------------");
		FibonacciSeries f1 = new FibonacciSeries();
		f1.test();
		System.out.println("------------");
		f1.test2();
		System.out.println("stream data");
		f1.stream1();
		System.out.println("--");
		f1.s();
	}

	void test() {
		int a = 8;
		int fact = 0;
		int last = 1;
		for (int i = 0; i < a; i++) {
			int next = fact + last;
			System.out.println("test>>" + next);
			fact = last;
			last = next;
		}
	}

	void test2() {
		int a = 4;
		int start = 0;
		int last = 1;
		for (int i = 0; i < a; i++) {
			int next = start + last;
			System.out.println("next>>" + next);
			start = last;
			last = next;
		}
	}

	void stream1() {
		System.out.println("-----stream1------");
		Stream.iterate(new int[] { 0, 1 }, p -> new int[] { p[1], p[0] + p[1] }).limit(7)
				.forEach(p -> System.out.println(p[0]));
	}

	void s() {
		Stream.iterate(new int[] { 1, 1 }, p -> new int[] { p[1], p[0] + p[1] })

				.limit(3).forEach(p -> System.out.println(p[0]));
	}
}

//0+1=1 , 1+1=2,1+2=3,2+3=5,3+5=8,5+8=13
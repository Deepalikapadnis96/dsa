package com.ntt.task;

import java.util.Objects;

public class StringIntern {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		String s1 = new String("hey");
		String s2 = "hey";
		String s3 = s1.intern();
		System.out.println(s1 == s2);// false because reference variables are pointing to different instance
		System.out.println(Objects.equals(s3, s2));// true same instance

	}
}

package com.ntt.task;

public abstract class Tree {
	abstract void branches(int big, int small);

	void height() {
		System.out.println(">>tree data");
	}
}

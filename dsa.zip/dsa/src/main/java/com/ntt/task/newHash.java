package com.ntt.task;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class newHash {
public static void main(String[] args) {
	Map<String, ArrayList<String>> mapData= new HashMap<String, ArrayList<String>>();
	ArrayList<String> listOfData = new ArrayList<String>();
	listOfData.add("A");
	listOfData.add("B");
	mapData.put("deep", listOfData);
	
	for(Map.Entry<String, ArrayList<String>> entry : mapData.entrySet()) {
		System.out.println("key::" + entry.getKey()+" value::"+ entry.getValue());
	}
}
}

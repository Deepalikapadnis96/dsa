package com.ntt.task;

import java.util.Arrays;

public class StringGetBytes {
	public static void main(String[] args) {
		String A = "ABCDEFGHIJK";
		byte[] B = A.getBytes();
		System.out.println(Arrays.toString(B));
	}
	
}

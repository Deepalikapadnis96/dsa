package com.ntt.task.stack;

import java.util.Stack;

public class ReverseLetterUsingStack {
	public static void main(String[] args) {
		String str = "Deepali Kapadnis";
		String reverse = reverseString(str);
		System.out.println("revrese string >>" + reverse);
		
	}

	public static String reverseString(String str) {
		Stack<Character> stack = new Stack<>();
		for (char ch : str.toCharArray()) {
			stack.push(ch);
		}
		StringBuilder reverse = new StringBuilder();
		while (!stack.isEmpty()) {
			reverse.append(stack.pop());
		}
		return reverse.toString();
	}
}

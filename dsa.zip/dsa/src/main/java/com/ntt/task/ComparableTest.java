package com.ntt.task;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ComparableTest implements Comparable<ComparableTest> {

	private int rollNum;
	private String name;

	
	public int compareTo(ComparableTest o) {
		if (this.rollNum > o.rollNum) {
			return 1;
		} else
			return -1;
	}

	public int getRollNum() {
		return rollNum;
	}

	public void setRollNum(int rollNum) {
		this.rollNum = rollNum;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Override
	public String toString() {
		return "ComparableTest [rollNum=" + rollNum + ", name=" + name + "]";
	}

	public ComparableTest(int rollNum, String name) {
		super();
		this.rollNum = rollNum;
		this.name = name;
	}

}

class check122 {
	public static void main(String[] args) {

		List<ComparableTest> list = new ArrayList<ComparableTest>();
		list.add(new ComparableTest(1, "deepali"));
		list.add(new ComparableTest(3, "monta"));
		list.add(new ComparableTest(2, "neha"));

		System.out.println("without sort::" + list);
		Collections.sort(list);
		System.out.println("with sort::" + list);
	}
}

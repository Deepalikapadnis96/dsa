package com.ntt.task;

import java.util.Objects;

public class App
{
    public static void main( String[] args )
    {
		int arr[] = new int[5];
		arr[0] = 1;
		arr[1] = 2;
		arr[2] = 3;
		arr[3] = 4;
		arr[4] = 5;

		// int arr[] = {1,2,3,4,5,6};
    	for(int arrays : arr) {
    		if(arrays ==4) {
			System.out.println( "array data :" + arrays);
		}
    	}

		String names[];
		names = new String[10];
		names[1] = "deepali";
		names[2] = "monta";
		names[3] = "neha";
		for (String data : names) {
			// for not null //for not null
			if ((Objects.nonNull(data)) || (data != null)) {
				System.out.println(" value " + data);
			} else {
				System.out.println("buzz: " + data);
			}
		}

         //multiplication table main
         MultiplicationTable multiplicationTable = new MultiplicationTable();
         multiplicationTable.multiple();
         System.out.println( "------------------" );
         multiplicationTable.multipleTable(3);
         System.out.println( "------------------" );
         multiplicationTable.tableFromTo(2, 4, 14);
    }

}

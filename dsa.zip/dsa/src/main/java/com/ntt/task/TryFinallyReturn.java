package com.ntt.task;

public class TryFinallyReturn {
	    public static void main(String[] args) {
	        int result = method1();
	        System.out.println(result);
	    }

	    private static int method1() {
	        int a = 2;
	        try {
	            a = a / a;
	            System.out.println("try");
	            return a;
	        } catch (Exception e) {
	            System.out.println("caught");
	            a = 5;
	            return a;
	        }
	        finally {
	            System.out.println("finally");
	            a = 10;
	            return a;
	        }
	    }
	}


package com.ntt.task;

//it is case sensitive and also if does not end with the given data then "false" else "true"
public class StringEndWith {
	public static void main(String[] args) {
		String end = "ntt data payment Services";
		System.out.println(end.endsWith("Services"));
		System.out.println(end.endsWith("ServiceS"));
		if (end.endsWith("ServiceSS")) {
			System.out.println("end with services");
		} else {
			System.out.println("does not end with services");
		}
	}
}

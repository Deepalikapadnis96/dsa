package com.ntt.task;

//print fuzzbus whn it divide bye 5 and 10, print fuss when divde by 5, else buzz
public class Que1ArrayElement {
	public static void main(String[] args) {

		int array[] = { 5, 25, 60, 43, 2 };
		for (int arr : array) {
			if (((arr % 5) == 0) && ((arr % 10) == 0)) {
				System.out.println("number divide by 5 and 10 (FUZZBUZZ): " + arr);
			} else if ((arr % 5) == 0) {
				System.out.println("divide by 5 (FUZZ): " + arr);
			} else {
				System.out.println("BUZZ");
			}
		}
	}
}

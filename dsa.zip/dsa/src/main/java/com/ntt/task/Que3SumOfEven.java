package com.ntt.task;

public class Que3SumOfEven {
	public static void main(String[] args) {
		int[] arr = { 2, 4, 89, 56, 77 };

		int sum = 0;
		for (int i=0;i<arr.length;i++) {
			if ((arr [i]% 2) == 0) {
				System.out.println("even:" + arr[i]);
				sum = arr[i] + sum;
			}
		}
		System.out.println("sum of even num: " + sum);
	}
}

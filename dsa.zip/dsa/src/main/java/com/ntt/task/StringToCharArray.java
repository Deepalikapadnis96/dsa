package com.ntt.task;

public class StringToCharArray {
	public static void main(String[] args) {
		String str = "deepali kapadnis";
		int count = 0;
		System.out.println(str.charAt(1));
		System.out.println(str.charAt(2));
		System.out.println(str.toCharArray());

		for (int i = 0; i < str.length(); i++) {
			if (str.charAt(i) == 'e') {
				count++;
			}
		}
		System.out.println(count);

	}

}

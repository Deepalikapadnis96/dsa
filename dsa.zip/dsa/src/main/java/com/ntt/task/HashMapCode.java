package com.ntt.task;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class HashMapCode {
	/**
	 * taking string(key) and list of string(multiple values)
	 */
	public static void main(String[] args) {
//string name, list num of services
		Map<String, ArrayList<String>> employeeData = new HashMap<String, ArrayList<String>>();

		ArrayList<String> deepaliList = new ArrayList<String>();
		deepaliList.add("datajar");
		deepaliList.add("filedata");
		deepaliList.add("testmodel");
		employeeData.put("Deepali", deepaliList);

		ArrayList<String> surajList = new ArrayList<String>();
		surajList.add("restapi");
		surajList.add("testdata");
		surajList.add("fileupdate");

		employeeData.put("Suraj", surajList);

		if (employeeData.containsKey("Deepali")) {
			ArrayList<String> arrayList = employeeData.get("Deepali");
			arrayList.add("fetchdata");
		}
		if (employeeData.containsKey("Deepali")) {
			ArrayList<String> arrayList = employeeData.get("Deepali");
			if (arrayList.contains("fetchdata")) {
				System.out.println("fetchdata is present");
			} else {
				System.out.println("fetchdata is not present");
			}
		}
		
		for (Map.Entry<String, ArrayList<String>> entry : employeeData.entrySet()) {
			String key = entry.getKey();
			ArrayList<String> value = entry.getValue();
			System.out.println("employeName: " + key + value);
		}
	}
}

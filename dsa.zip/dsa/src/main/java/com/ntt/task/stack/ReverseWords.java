package com.ntt.task.stack;

import java.util.Stack;
//Time complexity = O(n)
//Space Complexity =O(n)
public class ReverseWords {
	public static void main(String[] args) {
		String str = "Deepali Kapadnis";
		String reverseString = reverseString(str);
		System.out.println("reverse the word >>" + reverseString);

	}

	public static String reverseString(String str) {
		Stack<String> stack = new Stack<>();
		String[] split = str.split("\\s");//time complexity=O(n)
		for (String ch : split) {//time complexity=O(n)
			stack.push(ch);
		}
		StringBuilder stringBUilder = new StringBuilder();
		while (!stack.isEmpty()) {
			stringBUilder.append(stack.pop());
		
		if (!stack.isEmpty()) {
			stringBUilder.append(" ");
		}
		}
		return stringBUilder.toString();
	}
}
